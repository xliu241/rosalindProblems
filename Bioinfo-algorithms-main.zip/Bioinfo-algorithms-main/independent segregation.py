n=
for i in range(2*n):
    
